var a00111 =
[
    [ "inv_icm20648_augmented_init", "a00111.html#ga335e00a85e0071cc590dac160d64155c", null ],
    [ "inv_icm20648_augmented_sensors_get_gravity", "a00111.html#ga36977e1ec242e8f4e4a47700b3bfce4c", null ],
    [ "inv_icm20648_augmented_sensors_get_linearacceleration", "a00111.html#ga45547cbad5fa870f053b0aaff8a17527", null ],
    [ "inv_icm20648_augmented_sensors_get_orientation", "a00111.html#ga8c0bd2514ca6fb00022ddbd98342e0a5", null ],
    [ "inv_icm20648_augmented_sensors_set_odr", "a00111.html#gacfda45a3931b2d6049b6a7e7221a5957", null ],
    [ "inv_icm20648_augmented_sensors_update_odr", "a00111.html#gac2afd1f51f4c182312546c88099e3e14", null ]
];