var a00023 =
[
    [ "close", "a00023.html#a19b12568b42cd3054d01b090b72aa9e8", null ],
    [ "max_read_size", "a00023.html#abbf6792074059b384bba28c43e3323b6", null ],
    [ "max_write_size", "a00023.html#af03843e235f65d488d7d5a5bb89327e2", null ],
    [ "open", "a00023.html#a17c053aa1d0da865795be0fe83ddcc00", null ],
    [ "read_reg", "a00023.html#a5839f8fc39a22b8bd84c1e1356ae6fdc", null ],
    [ "register_interrupt_callback", "a00023.html#a82ad6c685693b4d32fe94611c04e128b", null ],
    [ "serif_type", "a00023.html#a7bd156558b438b41f198333a0bad50d5", null ],
    [ "write_reg", "a00023.html#ade31f6de16a7a30795f184a54c89653d", null ]
];