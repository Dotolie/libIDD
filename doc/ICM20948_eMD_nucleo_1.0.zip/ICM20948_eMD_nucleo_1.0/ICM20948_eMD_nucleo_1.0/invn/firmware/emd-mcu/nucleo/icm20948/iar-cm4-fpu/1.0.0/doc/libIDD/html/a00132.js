var a00132 =
[
    [ "inv_icm20948_sensor", "a00132.html#gae4dadf3a42a5c1defa9ea81b259bc39c", null ],
    [ "inv_icm20948_set_lowpower_or_highperformance", "a00132.html#gab6154f275dc7a9471aca6613cdc9a558", null ]
];