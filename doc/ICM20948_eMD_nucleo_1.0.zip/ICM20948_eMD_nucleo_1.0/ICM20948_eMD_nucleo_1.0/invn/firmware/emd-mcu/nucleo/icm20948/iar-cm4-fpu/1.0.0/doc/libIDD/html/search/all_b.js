var searchData=
[
  ['open',['open',['../a00023.html#a17c053aa1d0da865795be0fe83ddcc00',1,'inv_host_serif']]],
  ['orientation',['orientation',['../a00045.html#a3504627ae82ce9590dd0b87b50d1691b',1,'inv_sensor_event']]]
];
