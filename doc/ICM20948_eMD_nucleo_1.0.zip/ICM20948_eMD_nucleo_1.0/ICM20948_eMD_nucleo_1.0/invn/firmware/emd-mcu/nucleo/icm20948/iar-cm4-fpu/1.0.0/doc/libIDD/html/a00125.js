var a00125 =
[
    [ "COMPASS_I2C_SLV_READ", "a00125.html#ga94025fcc78d7b0214c9ea6cf978987a6", null ],
    [ "inv_icm20948_execute_read_secondary", "a00125.html#gabdee6df2b78e29dbb860b5d64d701c7b", null ],
    [ "inv_icm20948_execute_write_secondary", "a00125.html#ga77d80f7419b2f9b9a66d2749e0a4a10f", null ],
    [ "inv_icm20948_init_secondary", "a00125.html#ga7a7e39db56d71911c4fe3191bb87e04e", null ],
    [ "inv_icm20948_read_secondary", "a00125.html#gac8f3588040d2aca70dcb3ddecc6f4255", null ],
    [ "inv_icm20948_secondary_disable_i2c", "a00125.html#ga59d31f51fc184cfe51557bd729c0414a", null ],
    [ "inv_icm20948_secondary_enable_i2c", "a00125.html#ga94a02b7e831ef594bbac599a7eb1130f", null ],
    [ "inv_icm20948_secondary_restoreI2cOdr", "a00125.html#gafc45df1a6b2f6e050046a988c0efb100", null ],
    [ "inv_icm20948_secondary_saveI2cOdr", "a00125.html#gaca59a58da64304916e6d3dbff2421bd6", null ],
    [ "inv_icm20948_secondary_set_odr", "a00125.html#gad76f39c6d38adf34d38116463055e70f", null ],
    [ "inv_icm20948_secondary_stop_channel", "a00125.html#gac9f09102b1dba9e04d470e614cad8ac5", null ],
    [ "inv_icm20948_write_secondary", "a00125.html#gafbd5f9e38e44791274ebff7aa23a9b52", null ]
];